ANDROID APK (build from phone) - GitHub Actions

1) Create a GitHub repo and upload everything in this folder.
2) Open Actions → "Build Android APK (Godot 4.2.2)" → Run workflow.
3) Download Artifact: BabyFugglerCare-APK.
4) Install on Android: open APK → allow "Install unknown apps".

Notes:
- Private build. This workflow auto-generates a release keystore and signs the APK.
- If you want updates to install over the old app, you must keep the same keystore.
  (We can store the keystore as a GitHub Secret later.)
