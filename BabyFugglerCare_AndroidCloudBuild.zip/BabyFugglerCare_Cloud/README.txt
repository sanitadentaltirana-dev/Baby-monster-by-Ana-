Baby Fuggler Care (Private) - Godot 4.2+ Prototype

Run:
1) Install Godot 4.2+
2) Open project.godot
3) Press Play

Controls:
- Use buttons: Feed, Clean, Sleep, Play.
- Stats decay every 10 seconds.
- Coins increase with good care.
